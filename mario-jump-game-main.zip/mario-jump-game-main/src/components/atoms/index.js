import Birds from './Birds/Birds';
import Bricks from './Bricks/Bricks';
import Clouds from './Clouds/Clouds';
import KeyMessage from './KeyMessage/KeyMessage';
import Obstacles from './Obstacles/Obstacles';
import Sun from './Sun/Sun';

export { Birds, Bricks, Clouds, KeyMessage, Obstacles, Sun };