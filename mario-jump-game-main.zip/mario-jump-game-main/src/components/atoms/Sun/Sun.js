import "./Sun.css";

const Sun = () => {
  return (
    <div className="sun-container">
        <div className="sun"></div>
    </div>
  )
}
export default Sun